import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.testapp.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class WorkingOldMain {
    package com.example.testapp;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

    public class MainActivity extends AppCompatActivity {
        private EditText inputText;
        private TextView resultText;
        private Button saveButton, dictationButton;
        private List<String> inputWords, transcribedWords;
        private List<String> OGKeywords;
        private static final String[] FILLER_WORDS = {"a", "an", "the", "and", "but", "or", "of", "to", "for", "in", "on", "at", "by", "up", "with", "as", "is", "are", "was", "were", "be", "been"};
        private String dictation;
        private String manual;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            inputText = findViewById(R.id.input_text);
            resultText = findViewById(R.id.result_text);
            saveButton = findViewById(R.id.save_button);
            dictationButton = findViewById(R.id.dictation_button);
            inputWords = new ArrayList<>();
            transcribedWords = new ArrayList<>();
            OGKeywords = new ArrayList<>();




            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String input = inputText.getText().toString();
                    manual=input;
                    inputWords.clear();
                    OGKeywords.clear();
                    inputWords.addAll(Arrays.asList(input.split("\\s+")));
                    for (String word : inputWords) {
                        if (!Arrays.asList(FILLER_WORDS).contains(word.toLowerCase())) {
                            OGKeywords.add(word); //add keywords to ogkeywords
                        }
                    }




                }
            });

            dictationButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Implement dictation functionality to populate transcribedWords list
                    // For example:

                    promptSpeechInput();


                }
            });
        }

        private void promptSpeechInput() {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                    "Say something");
            try {
                startActivityForResult(intent, 100);
            } catch (ActivityNotFoundException a) {
                Toast.makeText(getApplicationContext(),
                        "Speech recognition is not supported on this device.",
                        Toast.LENGTH_SHORT).show();
            }
        }

        /**
         * Receiving speech input
         * */
        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            switch (requestCode) {
                case 100: {
                    if (resultCode == RESULT_OK && null != data) {

                        ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                        dictation = result.get(0);
                        transcribedWords.clear();

                        dictation.toLowerCase();
                        transcribedWords.addAll(Arrays.asList(dictation.split("\\s+")));
                        displayResult();
                    }
                    break;
                }

            }
        }

        private void displayResult() {
            List<String> missingWords = new ArrayList<>();
            List<String> sentencesWithMissingWords = new ArrayList<>();

            for (String word : OGKeywords) {
                if (!transcribedWords.contains(word)) {
                    missingWords.add(word);
                    List<String> sentences = getSentencesContainingWord(word);
                    for (String sentence : sentences) {
                        if (!sentencesWithMissingWords.contains(sentence)) {
                            sentencesWithMissingWords.add(sentence);
                        }
                    }
                }
            }


            String result = "";
            if (missingWords.isEmpty()) {
                result += "All words were there!.";
            } else {
                result += "Missing words: " + TextUtils.join(", ", missingWords) + "\n\n";
                result += "Sentences with missing words:\n";
                result += TextUtils.join("\n", sentencesWithMissingWords);
            }
            resultText.setText(result);
        }

        private List<String> getSentencesContainingWord(String word) {
            List<String> sentences = new ArrayList<>();
            String input = inputText.getText().toString();
            String[] inputSentences = input.split("\\.");
            for (String sentence : inputSentences) {
                if (sentence.contains(word)) {
                    sentences.add(sentence.trim() + ".");
                }
            }

            return sentences;
        }
    }

}





NOTE:
private String getBodyText(String url) {
        new Thread(new Runnable() {
@Override
public void run() {
final StringBuilder builder = new StringBuilder();

        try {

        Document doc = Jsoup.connect(url).get();
        Elements paragraphs = doc.select("div#mw-content-text > div > p");
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (int i = 0; i < paragraphs.size() && count < 3; i++) {
        String paragraph = paragraphs.get(i).text();
        if (!paragraph.isEmpty()) {
        sb.append(paragraph);
        sb.append("\n\n");
        count++;
        }
        }
        scrapedText = sb.toString();

        } catch (Exception e) {
        builder.append("Error : ").append(e.getMessage()).append("\n");
        }

        scrapedText=builder.toString();


        }
        }).start();
        }
