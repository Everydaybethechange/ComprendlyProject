package com.example.testapp;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.TextUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.jsoup.Jsoup;
import org.jsoup.parser.Parser;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MainActivity extends AppCompatActivity {
    private EditText inputText;
    private TextView resultText;
    private Button saveButton, dictationButton;
    private List<String> inputWords, transcribedWords;
    private List<String> OGKeywords;
    private static final String[] FILLER_WORDS = {"a", "an", "the", "and", "but", "or", "of", "to",
            "for", "in", "on", "at", "by", "up", "with", "as", "is", "are", "he", "his", "her", "apparently", "supposedly", "their", "she", "they", "was", "were", "be",
            "been", "who", "whom", "whose", "which", "that",
            "whoever", "whomever", "whichever", "whatever",
            "whosever", "whosesoever", "whatsoever",
            "when", "where", "why", "how",
            "whoever's", "whomever's", "whosever's", "whichever's", "whatever's",
            "that's", "who's", "whom's", "whose's", "which's",
            "whomeversoever", "whosesoever's", "whicheversoever",
            "whatsomever", "whatsoever's",
            "where's", "when's", "why's", "how's",
            "whoso", "whosoever", "whomsoever", "whosever", "whichsoever",
            "what", "whensoever", "wheresoever", "whyever", "however"};
    private String dictation;
    private String manual;
    private String url;
    private String scrapedText;
    private boolean wik = true;
    ImageView introImage;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.input_text);
        resultText = findViewById(R.id.result_text);
        saveButton = findViewById(R.id.save_button);
        dictationButton = findViewById(R.id.dictation_button);
        inputWords = new ArrayList<>();
        transcribedWords = new ArrayList<>();
        OGKeywords = new ArrayList<>();

        introImage = findViewById(R.id.intro_image);
        Glide.with(this).load(R.drawable.gifgif).into(introImage);

        introImage.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              introImage.setVisibility(View.GONE);
                                          }
                                      });
        // Initialize Switch and its label
        Switch switchInput = findViewById(R.id.switch_input);
        TextView switchLabel = findViewById(R.id.switch_label);
        switchInput.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    switchLabel.setText("Wikipedia Mode");
                    wik =true;
                } else {
                    switchLabel.setText("Manual Input Mode");
                    wik=false;
                }
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                introImage.setVisibility(View.GONE);
                String input = inputText.getText().toString();
                    if (wik) {
                        if (input.contains(".m.")) {
                            input = input.replace(".m", ""); // Removing ".m" from mobile Wikipedia sites
                        }
                        url = input;
                        new FetchWikiTask().execute(url);
                    } else {

                        scrapedText=input;// Do something with the text, e.g., save it to a string or display it in a TextView
                        resultText.setText(input);
                        inputWords.clear();
                        OGKeywords.clear();
                        inputWords.addAll(Arrays.asList(input.split("\\s+")));
                        for (String word : inputWords) {
                            if (!Arrays.asList(FILLER_WORDS).contains(word.toLowerCase())) {
                                OGKeywords.add(word); //add keywords to ogkeywords
                            }
                        }
                }
            }
        });

        dictationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                introImage.setVisibility(View.GONE);
                    promptSpeechInput();
            }
        });
    }



    private void promptSpeechInput() {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Say something");
        try {
            startActivityForResult(intent, 100);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    "Speech recognition is not supported on this device. :(",
                    Toast.LENGTH_SHORT).show();
        }

    }

   // After transcription is finished
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 100: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    dictation = result.get(0);
                    transcribedWords.clear();

                    dictation.toLowerCase();
                    transcribedWords.addAll(Arrays.asList(dictation.split("\\s+")));


                    displayResult();
                }
                break;
            }

        }
    }





    private class FetchWikiTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String result = null;
            try {
                URL url = new URL(params[0]);
                if (!url.getHost().endsWith("wikipedia.org")) {
                    // Non-Wikipedia page
                    return null;
                }
                Document document = Jsoup.connect(params[0]).get();
                Elements paragraphs = document.select("div.mw-parser-output > p");
                StringBuilder sb = new StringBuilder();
                int count = 0;
                for (int i = 0; i < paragraphs.size() && count < 3; i++) {
                    String paragraph = paragraphs.get(i).text();
                    if (!paragraph.isEmpty()) {
                        sb.append(paragraph);
                        sb.append("\n\n");
                        count++;
                    }
                }
                result = sb.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            } catch (IndexOutOfBoundsException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                Toast.makeText(MainActivity.this, "First 3 paragraphs saved to text", Toast.LENGTH_SHORT).show();
                scrapedText=result;
                resultText.setText(result);
                inputWords.clear();
                OGKeywords.clear();
                inputWords.addAll(Arrays.asList(result.split("\\s+")));
                for (String word : inputWords) {
                    if (!Arrays.asList(FILLER_WORDS).contains(word.toLowerCase())) {
                        OGKeywords.add(word); //add keywords to ogkeywords
                    }
                }
            } else {
                Toast.makeText(MainActivity.this, "Not a Wikipedia URL", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static List<String> cleanString(List<String> strings) { // Removes uppercases and non alphabetical characters
        List<String> processedStrings = new ArrayList<String>();
        for (String str : strings) {
            String processedStr = str.toLowerCase().replaceAll("[^a-zA-Z0-9]+", "");
            processedStrings.add(processedStr);
        }
        return processedStrings;
    }


    private void displayResult() {
        List<String> missingWords = new ArrayList<>();
        List<String> sentencesWithMissingWords = new ArrayList<>();




        for (String word : cleanString(OGKeywords)) {
            if (!transcribedWords.contains(word)) {
                missingWords.add(word);
                List<String> sentences = getSentencesContainingWord(word);
                for (String sentence : sentences) {
                    if (!sentencesWithMissingWords.contains(sentence)) {
                        sentencesWithMissingWords.add(sentence);
                    }
                }
            }
        }


        String result = "";
        if (missingWords.isEmpty()) {
            result += "All words were there!.";
        } else {
            result += "Missing words: " + TextUtils.join(", ", missingWords) + "\n\n";
            result += "Sentences with missing words:\n";
            result += TextUtils.join("\n", sentencesWithMissingWords);
        }
        resultText.setText(result);
        //resultText.setText(scrapedText);
    }

    private List<String> getSentencesContainingWord(String word) {
        List<String> sentences = new ArrayList<>();
        String input = scrapedText;
        String[] inputSentences = input.split("\\.");
        for (String sentence : inputSentences) {
            if (sentence.contains(word)) {
                sentences.add(sentence.trim() + ".");
            }
        }

    return sentences;
    }
}
