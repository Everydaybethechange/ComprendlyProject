package com.example.testapp;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;

public class newnew {

    public static void main(String[] args) {
        String url = "https://en.wikipedia.org/wiki/Java_(programming_language)";
        try {
            Document document = Jsoup.connect(url).get();
            Elements paragraphs = document.select("div#mw-content-text > div > p");
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (int i = 0; i < paragraphs.size() && count < 3; i++) {
                String paragraph = paragraphs.get(i).text();
                if (!paragraph.isEmpty()) {
                    sb.append(paragraph);
                    sb.append("\n\n");
                    count++;
                }
            }
            String result = sb.toString();
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

